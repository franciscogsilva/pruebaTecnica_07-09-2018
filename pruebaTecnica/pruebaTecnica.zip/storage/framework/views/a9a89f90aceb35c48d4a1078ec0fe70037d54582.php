<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<?php $__currentLoopData = $lanzamientos->albums->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lanzamiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col s12 m4 l4">
					<div class="card">
						<div class="card-image waves-effect waves-block waves-light">
							<img class="activator responsive-img" src="<?php echo e($lanzamiento->images[1]->url); ?>" alt="<?php echo e($lanzamiento->name); ?>">
						</div>
						<div class="card-content">
							<span class="card-title activator grey-text text-darken-4"><b><?php echo e($lanzamiento->name); ?></b></span>
							<?php $__currentLoopData = $lanzamiento->artists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a href="<?php echo e(url('/artista/'.$artist->id.'?token='.$token)); ?>"><p><?php echo e($artist->name); ?></p></a>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col s4 m2 l2">
				<img class="activator responsive-img circle" src="<?php echo e($artist->images[2]->url); ?>" alt="<?php echo e($artist->name); ?>">				
			</div>
			<div class="col s8 m10 l10">
				<h1 style="color: #FFF;"><?php echo e($artist->name); ?></h1>
				<p><a href="<?php echo e($artist->external_urls->spotify); ?>" style="color: BLUE;">Ir a la pagina del Artista</a></p>
			</div>
		</div>
		<div class="row">
			<div class="col s12">
				<table class="responsive-table" style="color: #FFF;">
					<thead>
						<tr>
							<th>Foto</th>
							<th>Album</th>
							<th>Canción</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $artist_tracks->tracks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $track): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td>
									<img src="<?php echo e($track->album->images[1]->url); ?>" alt="<?php echo e($track->album->name); ?>" class="activator responsive-img" style="width: 70px;">
								</td>
								<td><?php echo e($track->album->name); ?></td>
								<td><?php echo e($track->name); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
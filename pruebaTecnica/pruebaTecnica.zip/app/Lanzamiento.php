<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lanzamiento extends Model
{
    //
}

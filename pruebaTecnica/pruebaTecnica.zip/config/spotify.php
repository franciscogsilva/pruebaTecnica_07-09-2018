<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Application Name
    |--------------------------------------------------------------------------
    |
    | This value is the name of your application. This value is used when the
    | framework needs to place the application's name in a notification or
    | any other location as required by the application or its packages.
    */

    'SPOTIFY_CLIENT_ID' => env('SPOTIFY_CLIENT_ID', '9fce456538bf4b149aa8f920d53e694b'),



    'SPOTIFY_CLIENT_SECRET' => env('SPOTIFY_CLIENT_SECRET', '77057e301d83427e8f3082ede393836f'),


    
    'SPOTIFY_CALLBACK_URL' => env('SPOTIFY_CALLBACK_URL', 'localhost:8000/'),

];
